# Move Stdlib Modules

This is the reference documentation of the Move standard library.
For on overview of the Move language, see the [Move Book][move-book].

## Index

> {{move-index}}
