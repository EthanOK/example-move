# Aptos Standard Library

This is the reference documentation of the Aptos standard library.

## Index

> {{move-index}}
